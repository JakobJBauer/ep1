/*
    Aufgabe 5) Eindimensionale Arrays und File I/O
*/

import java.awt.*;

public class Aufgabe5 {

    private static String[] readFileData(String fileName, int lineStart, int lineEnd) {
        In fileReader = new In(fileName);

        //TODO: Implementieren Sie hier Ihre Lösung für die Angabe
        return null; //Zeile kann geändert oder entfernt werden.
    }

    private static void extractData(String[] dataArray, int[] resultArray, int numColumn, int entriesPerYear) {
        //TODO: Implementieren Sie hier Ihre Lösung für die Angabe
    }

    private static void drawChart(int[] sunHours) {
        int width = 1275;
        int height = 600;
        StdDraw.setCanvasSize(width, height);
        StdDraw.setXscale(0, width);
        StdDraw.setYscale(0, height);

        //TODO: Implementieren Sie hier Ihre Lösung für die Angabe
    }

    public static void main(String[] args) {
        //TODO: Implementieren Sie hier Ihre Lösung für die Angabe
    }
}
